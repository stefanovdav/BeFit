package org.beFit.v1.dto;

public record LoginDTO(String accessToken, String username, String avatarURL) {
}
